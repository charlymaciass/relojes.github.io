<nav>
	<ul>
		<li><a href="/latam#shop">RELOJES</a></li>
		<li><a href="/latam#proceso">PROCESO</a></li>
		<li><a href="/latam"><img src="imgs/logoNegro.png" alt="logo Lengas"></a></li>
		<li><a href="/latam#impacto">IMPACTO</a></li>
		<li><a href="/latam#somos">SOMOS</a></li>
	</ul>
</nav>
<style>
nav{ padding: 3% 0 }
nav li{
	font-family: 'Vincent'; font-weight: 400;
}
nav img{ width: 50%; display: block; margin: auto; }
nav ul{
	display: flex;
	align-items: center;
	justify-content: center;
}
nav li{
	font-size: 1.2em;
	/*margin: 0 2%;*/
	padding: 0.2%;
	margin: 0 1.8%;
	position: relative;
	z-index: 9;
}
nav a{ color: inherit; }

nav li:before{
	content: '';
    position: absolute;
    background-image: radial-gradient( #bc8c3e 50% , rgba(0,0,0,0) 70%);
    opacity: 0.6;
    display: block;
    width: 0%;
    height: 10%;
    bottom: 0;
    left: -10%;
    transition: .2s ease-in-out;
    transform-origin: 0% 50%;
    border-top: none;
    border-right: none;
    z-index: 2;
    transform: rotate(-9deg);
    outline: none;
}
nav li:hover:before{
    width: 120%;
}
	

</style>
