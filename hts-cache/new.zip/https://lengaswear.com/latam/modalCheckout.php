 
<style>

#ppl-static{
    transition: transform 0.3s;
}

</style>

<div id="fondoModal">
	<div>
		<div id="formCheckout">
		    <div id="tits">
				<h4>COMPLETAR PEDIDO | Ya casi!</h4>
				<h2>LlenA el ForMulaRio</h2>
			</div>
			<div id="inputs">
				<input id="nombreP" class="inputes" placeholder="Nombre" type="text">
				<input id="mailP" class="inputes" placeholder="Email" type="email">
				<input id="telefonoP" class="inputes" placeholder="Telefono"  type="text">
				<br>
				
				<br>
				<div style="font-weight: bold;margin-left: 4px;margin-bottom:3px;">Dirección de envío:</div>
                <input type="text" id="country" class="inputes" placeholder="País" name="pais">
				<input type="text" id="street" class="inputes" placeholder="Calle" name="street">
				<div style="display: flex; flex-direction: row;width: 101%;">
					<input type="text" id="street-number" class="inputes" placeholder="Numero" name="street-number"><input type="text" id="floor" class="inputes" placeholder="Departamento (opcional)" name="floor">
				</div>
				<input type="text" id="city" class="inputes" placeholder="Ciudad" name="city">
				<input type="text" id="district" class="inputes" placeholder="Distrito (opcional)" name="district">
				<input type="text" id="zip-code" class="inputes" placeholder="Codigo Postal (ZIP)" name="zip-code">

				<br>
				<br>

				<div> 
	            <select id="haceCuantoP" class="inputes">
                    <option value="" hidden>Hace cuanto nos conociste?</option>
                    <option value="Menos de 2 semanas">Menos de 2 semanas</option>
                    <option value="Entre 2 semanas y 1 mes">Entre 2 semanas y 1 Mes</option>
                    <option value="Entre 1 y 3 meses">Entre 1 y 3 Meses</option>
                    <option value="Mas de 3 meses">Mas de 3 Meses</option>
                    <option value="Mas de 6 meses">Mas de 6 Meses</option>
                </select>
            </div>
            <div> 
	            <select id="fuenteP" class="inputes">
                    <option value="" hidden>Por donde nos conociste?</option>
                    <option value="Referido">Me los mostro un amigx</option>
                    <option value="Instagram Ads">Anuncio/Publicidad de Instagram</option>
                    <option value="Facebook Ads">Anuncio/Publicidad de Facebook</option>
                    <option value="Influencer">Lo refirio un influencer</option>
                    <option value="Prensa">Prensa</option>
                    <option value="Otro">Otro</option>
                </select>

            </div>
				<input type="hidden" id="fueguinoAlert" value="false">
				<input type="hidden" id="cuponstatus" value="">
       
				<div id="infoRedirec" style="text-align: center; padding: 6px;"><b>VAMOS A DESPACHAR 7 DIAS POST-COMPRA</div>
				<p onclick="verTerminos()" style="font-size: 0.8em; text-align: center; font-weight: bold; cursor: pointer; color: #9e9e9e;">Te quedan dudas? - LEER TERMINOS Y CONDICIONES</p>
		 </div>
				<div id="ppl-static"><div style="display: flex;flex-direction: row;justify-content: center;margin-top: 10px;"></div></div>
				<div id="enviarCorpo" onclick="proceder()"><!--PROCEDER CON LA COMPRA --> 
<div class="order"><span class="default">CONTINUAR</span><span class="success">Verificando...
    <svg viewbox="0 0 12 10">
      <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
    </svg></span>
  <div class="box"></div>
  <div class="truck">
    <div class="back">
        <img src="imgs/logoNegro.png" width="80%" alt="">
    </div>
    <div class="front">
      <div class="window"></div>
    </div>
    <div class="light top"></div>
    <div class="light bottom"></div>
  </div>
  <div class="lines"></div>
</div>

<style>
:root {
  --primary: #275EFE;
  --primary-light: #7699FF;
  --dark: #bc8c3e;
  --grey-dark: #3F4656;
  --grey: #6C7486;
  --grey-light: #CDD9ED;
  --white: #FFF;
  --green: #16BF78;
  --sand: #DCB773;
  --sand-light: #EDD9A9;
}

.order {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  border: 0;
  background: var(--dark);
  position: relative;
  height: 63px;
  width: 288px;
  padding: 0;
  outline: none;
  cursor: pointer;
  border-radius: 32px;
  -webkit-mask-image: -webkit-radial-gradient(white, black);
  -webkit-tap-highlight-color: transparent;
  overflow: hidden;
  transition: -webkit-transform .3s ease;
  transition: transform .3s ease;
  transition: transform .3s ease, -webkit-transform .3s ease;
  transform: scale(0.7)
}

.order span {
  --o: 1;
  position: absolute;
  left: 0;
  right: 0;
  text-align: center;
  top: 19px;
  line-height: 24px;
  color: var(--white);
  font-size: 16px;
  font-weight: 600;
  opacity: var(--o);
  transition: opacity .3s ease;
  transform: scale(1.5)
}
@media only screen and (max-width: 600px) {
  .order span {
    transform: scale(1.2)!important
  }
}
.order span.default {
  transition-delay: .3s;
  font-size: 0.9em;
    font-weight: 600;
}
.order span.success {
  --offset: 16px;
  transform: scale(1.2);

  --o: 0;
  
}
.order span.success svg {
  width: 12px;
  height: 10px;
  display: inline-block;
  vertical-align: top;
  fill: none;
  margin: 7px 0 0 4px;
  stroke: var(--green);
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: var(--offset);
  transition: stroke-dashoffset .3s ease;
}
.order:active {
  /* -webkit-transform: scale(0.96);
          transform: scale(0.96); */
}
.order .lines {
  opacity: 0;
  position: absolute;
  height: 3px;
  background: var(--white);
  border-radius: 2px;
  width: 6px;
  top: 30px;
  left: 100%;
  box-shadow: 15px 0 0 var(--white), 30px 0 0 var(--white), 45px 0 0 var(--white), 60px 0 0 var(--white), 75px 0 0 var(--white), 90px 0 0 var(--white), 105px 0 0 var(--white), 120px 0 0 var(--white), 135px 0 0 var(--white), 150px 0 0 var(--white), 165px 0 0 var(--white), 180px 0 0 var(--white), 195px 0 0 var(--white), 210px 0 0 var(--white), 225px 0 0 var(--white), 240px 0 0 var(--white), 255px 0 0 var(--white), 270px 0 0 var(--white), 285px 0 0 var(--white), 300px 0 0 var(--white), 315px 0 0 var(--white), 330px 0 0 var(--white);
}
.order .back img{
    display:block;
    margin: auto;
    margin-top: 15%;
}
.order .back,
.order .box {
  --start: var(--white);
  --stop: var(--grey-light);
  border-radius: 2px;
  background: linear-gradient(var(--start), var(--stop));
  position: absolute;
}
.order .truck {
  width: 60px;
  height: 41px;
  left: 100%;
  z-index: 1;
  top: 11px;
  position: absolute;
  -webkit-transform: translateX(24px);
          transform: translateX(24px);
}
.order .truck:before, .order .truck:after {
  --r: -90deg;
  content: '';
  height: 2px;
  width: 20px;
  right: 58px;
  position: absolute;
  display: block;
  background: var(--white);
  border-radius: 1px;
  -webkit-transform-origin: 100% 50%;
          transform-origin: 100% 50%;
  -webkit-transform: rotate(var(--r));
          transform: rotate(var(--r));
}
.order .truck:before {
  top: 4px;
}
.order .truck:after {
  --r: 90deg;
  bottom: 4px;
}
.order .truck .back {
  left: 0;
  top: 0;
  width: 60px;
  height: 41px;
  z-index: 1;
}
.order .truck .front {
  overflow: hidden;
  position: absolute;
  border-radius: 2px 9px 9px 2px;
  width: 26px;
  height: 41px;
  left: 60px;
}
.order .truck .front:before, .order .truck .front:after {
  content: '';
  position: absolute;
  display: block;
}
.order .truck .front:before {
  height: 13px;
  width: 2px;
  left: 0;
  top: 14px;
  background: linear-gradient(var(--grey), var(--grey-dark));
}
.order .truck .front:after {
  border-radius: 2px 9px 9px 2px;
  background: var(--primary);
  width: 24px;
  height: 41px;
  right: 0;
}
.order .truck .front .window {
  overflow: hidden;
  border-radius: 2px 8px 8px 2px;
  background: var(--primary-light);
  -webkit-transform: perspective(4px) rotateY(3deg);
          transform: perspective(4px) rotateY(3deg);
  width: 22px;
  height: 41px;
  position: absolute;
  left: 2px;
  top: 0;
  z-index: 1;
  -webkit-transform-origin: 0 50%;
          transform-origin: 0 50%;
}
.order .truck .front .window:before, .order .truck .front .window:after {
  content: '';
  position: absolute;
  right: 0;
  background: #2d3565!important;
}
.order .truck .front .window:before {
  top: 0;
  bottom: 0;
  width: 14px;
  background: var(--dark);
}
.order .truck .front .window:after {
  width: 14px;
  top: 7px;
  height: 4px;
  position: absolute;
  background: rgba(255, 255, 255, 0.14);
  -webkit-transform: skewY(14deg);
          transform: skewY(14deg);
  box-shadow: 0 7px 0 rgba(255, 255, 255, 0.14);
}
.order .truck .light {
  width: 3px;
  height: 8px;
  left: 83px;
  -webkit-transform-origin: 100% 50%;
          transform-origin: 100% 50%;
  position: absolute;
  border-radius: 2px;
  -webkit-transform: scaleX(0.8);
          transform: scaleX(0.8);
  background: #f0dc5f;
}
.order .truck .light:before {
  content: '';
  height: 4px;
  width: 7px;
  opacity: 0;
  -webkit-transform: perspective(2px) rotateY(-15deg) scaleX(0.94);
          transform: perspective(2px) rotateY(-15deg) scaleX(0.94);
  position: absolute;
  -webkit-transform-origin: 0 50%;
          transform-origin: 0 50%;
  left: 3px;
  top: 50%;
  margin-top: -2px;
  background: linear-gradient(90deg, #f0dc5f, rgba(240, 220, 95, 0.7), rgba(240, 220, 95, 0));
}
.order .truck .light.top {
  top: 4px;
}
.order .truck .light.bottom {
  bottom: 4px;
}
.order .box {
  --start: var(--sand-light);
  --stop: var(--sand);
  width: 21px;
  height: 21px;
  right: 100%;
  top: 21px;
}
.order .box:before, .order .box:after {
  content: '';
  top: 10px;
  position: absolute;
  left: 0;
  right: 0;
}
.order .box:before {
  height: 3px;
  margin-top: -1px;
  background: rgba(0, 0, 0, 0.1);
}
.order .box:after {
  height: 1px;
  background: rgba(0, 0, 0, 0.15);
}
.order.animate .default {
  --o: 0;
  transition-delay: 0s;
}

.order.animate .success {
  --offset: 0;
  --o: 1;
  /* transition-delay: 5.6s; */
    transition-delay: 4.2s;
}
.order.animate .success svg {
  /* transition-delay: 5.84s; */
    transition-delay: 4.5s;
}
.order.animate .truck {
  -webkit-animation: truck 6s ease forwards;
          animation: truck 6s ease forwards;
}
.order.animate .truck:before {
  -webkit-animation: door1 1.92s ease forwards .24s;
          animation: door1 1.92s ease forwards .24s;
}
.order.animate .truck:after {
  -webkit-animation: door2 1.92s ease forwards .48s;
          animation: door2 1.92s ease forwards .48s;
}
.order.animate .truck .light:before, .order.animate .truck .light:after {
  -webkit-animation: light 6s ease forwards;
          animation: light 6s ease forwards;
}
.order.animate .box {
  -webkit-animation: box 6s ease forwards;
          animation: box 6s ease forwards;
}
.order.animate .lines {
  -webkit-animation: lines 6s ease forwards;
          animation: lines 6s ease forwards;
}

@-webkit-keyframes truck {
  10%,
    30% {
    -webkit-transform: translateX(-164px);
            transform: translateX(-164px);
  }
  40% {
    -webkit-transform: translateX(-104px);
            transform: translateX(-104px);
  }
  60% {
    -webkit-transform: translateX(-224px);
            transform: translateX(-224px);
  }
  75%,
    100% {
    -webkit-transform: translateX(24px);
            transform: translateX(24px);
  }
}

@keyframes truck {
  10%,
    30% {
    -webkit-transform: translateX(-164px);
            transform: translateX(-164px);
  }
  40% {
    -webkit-transform: translateX(-104px);
            transform: translateX(-104px);
  }
  60% {
    -webkit-transform: translateX(-224px);
            transform: translateX(-224px);
  }
  75%,
    100% {
    -webkit-transform: translateX(24px);
            transform: translateX(24px);
  }
}
@-webkit-keyframes lines {
  0%,
    30% {
    opacity: 0;
    -webkit-transform: scaleY(0.7) translateX(0);
            transform: scaleY(0.7) translateX(0);
  }
  35%,
    65% {
    opacity: 1;
  }
  70% {
    opacity: 0;
  }
  100% {
    -webkit-transform: scaleY(0.7) translateX(-400px);
            transform: scaleY(0.7) translateX(-400px);
  }
}
@keyframes lines {
  0%,
    30% {
    opacity: 0;
    -webkit-transform: scaleY(0.7) translateX(0);
            transform: scaleY(0.7) translateX(0);
  }
  35%,
    65% {
    opacity: 1;
  }
  70% {
    opacity: 0;
  }
  100% {
    -webkit-transform: scaleY(0.7) translateX(-400px);
            transform: scaleY(0.7) translateX(-400px);
  }
}
@-webkit-keyframes light {
  0%,
    30% {
    opacity: 0;
    -webkit-transform: perspective(2px) rotateY(-15deg) scaleX(0.88);
            transform: perspective(2px) rotateY(-15deg) scaleX(0.88);
  }
  40%,
    100% {
    opacity: 1;
    -webkit-transform: perspective(2px) rotateY(-15deg) scaleX(0.94);
            transform: perspective(2px) rotateY(-15deg) scaleX(0.94);
  }
}
@keyframes light {
  0%,
    30% {
    opacity: 0;
    -webkit-transform: perspective(2px) rotateY(-15deg) scaleX(0.88);
            transform: perspective(2px) rotateY(-15deg) scaleX(0.88);
  }
  40%,
    100% {
    opacity: 1;
    -webkit-transform: perspective(2px) rotateY(-15deg) scaleX(0.94);
            transform: perspective(2px) rotateY(-15deg) scaleX(0.94);
  }
}
@-webkit-keyframes door1 {
  30%,
    50% {
    -webkit-transform: rotate(32deg);
            transform: rotate(32deg);
  }
}
@keyframes door1 {
  30%,
    50% {
    -webkit-transform: rotate(32deg);
            transform: rotate(32deg);
  }
}
@-webkit-keyframes door2 {
  30%,
    50% {
    -webkit-transform: rotate(-32deg);
            transform: rotate(-32deg);
  }
}
@keyframes door2 {
  30%,
    50% {
    -webkit-transform: rotate(-32deg);
            transform: rotate(-32deg);
  }
}
@-webkit-keyframes box {
  8%,
    10% {
    -webkit-transform: translateX(40px);
            transform: translateX(40px);
    opacity: 1;
  }
  25% {
    -webkit-transform: translateX(112px);
            transform: translateX(112px);
    opacity: 1;
  }
  26% {
    -webkit-transform: translateX(112px);
            transform: translateX(112px);
    opacity: 0;
  }
  27%,
    100% {
    -webkit-transform: translateX(0px);
            transform: translateX(0px);
    opacity: 0;
  }
}
@keyframes box {
  8%,
    10% {
    -webkit-transform: translateX(40px);
            transform: translateX(40px);
    opacity: 1;
  }
  25% {
    -webkit-transform: translateX(112px);
            transform: translateX(112px);
    opacity: 1;
  }
  26% {
    -webkit-transform: translateX(112px);
            transform: translateX(112px);
    opacity: 0;
  }
  27%,
    100% {
    -webkit-transform: translateX(0px);
            transform: translateX(0px);
    opacity: 0;
  }
}

html {
  /* box-sizing: border-box; */
  -webkit-font-smoothing: antialiased;
}

* {
  box-sizing: inherit;
}
*:before, *:after {
  box-sizing: inherit;
}

/* body {
  min-height: 100vh;
  font-family: Roboto, Arial;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #E4ECFA;
}
body .dribbble {
  position: fixed;
  display: block;
  right: 20px;
  bottom: 20px;
}
body .dribbble img {
  display: block;
  height: 28px;
} */

</style>
<script>
// $('.order').click(function(e) {

// let button = $(this);

// if(!button.hasClass('animate')) {
//     button.addClass('animate');
//     setTimeout(() => {
//         button.removeClass('animate');
//     }, 10000);
// }

// });

</script></div>
				<img id="cerrarModal" src="imgs/cancel.png" alt="">
		</div>
		
	</div>
</div>
<style>

#fondoModal{
	position: fixed;
	top: 0;
	width: 100%;
	height: 100%;
	background: rgba(0,0,0,0.7);
	display: none;
	z-index: 9999!important;
	opacity: 0;
	overflow: auto;
	/*filter: blur(15px);*/
}

#fondoModal>div{
	padding: 1.5% 3%;
	background: white;
	display: block;
	position: absolute;
	width: 50vw;
	/*max-height:60vh;*/
	left: 20vw;
	top: 3%;
	filter: blur(0px);
	border: 1px solid #ddd;
	border-radius: 3px;
	box-shadow: 0px 0px 3px 2px #515151;
	transition: .3s;
	transform: scale(0);
}

#modal h4{
	color: #bc8c3e;
	font-size: 1em;
}
#modal h2{
	margin-bottom: 5%;
	font-size: 2em;
}

#modal form{ position: relative; }


.inputes{
	background: #f0f0f0;
	resize: none;
	border: none;
	border: none;
	padding: 8px 2%;
	border-radius: 3px;
	outline: none;
	width: 96%;
	margin: 0.7% 0.5%;
	font-family: 'Montserrat';
	font-weight: 500;
	transition: .2s;
	font-size: 0.9em;
}
.inputes:placeholder{
	font-family: 'Montserrat';
}
.inputes:focus{
	box-shadow: 1px 1px 2px 1px #ddd;
}
#enviarCorpo{
	margin: auto;
	/*margin-top: 2%;*/
	/*padding: 7px 15px;*/
	cursor: pointer;
	font-family: 'Montserrat';
	text-transform: uppercase;
	font-weight: 600;
	background: transparent;
	/*border: 2px solid #bc8c3e;*/
	color: #bc8c3e;
	transition: .2s;
	display: table;
	outline: none;
    font-size: 0.9em;
    text-align: center;
}
.selectisoide{
	width: 100%;
	outline: none;
}

#confirmacion{
	font-family: 'Vincent';
	color: #bc8c3e;
	margin: 5% 1%;
	width: 100%;
	display: none;
}
#cerrarModal{
	position: absolute;
	top: 1%;
	right: 1%;
	cursor: pointer;
}

.completar{
	border: 1.5px solid #ef5656;
}

#formCheckout h4{
    font-family: 'Vincent';
}
#formCheckout h2{
    font-family: 'Swistblnk Monthoers';
    
}




@media only screen and (max-width: 612px) {
    
.sentMargin{
    margin-top: 65%;
}
    
#porque{
    /*font-size: 2.2em!important;*/
    font-size: 0.9em;
}
    
	#fondoModal>div{
		padding: 5%;
    	width: 80vw;
    	left: 5vw;
    	top: -2vh;
    	
	}


#fondoModal>div{
    left: 0!important;
    width: 90%!important;
}
	.inputes{
		margin: 2% 0.5%;
	}
	#cerrarModal{
		/*top: -3.5%;*/
  /*  	right: -5%;*/
	}
	#infoRedirec, #fondoModal b{
	    font-size: 1.2rem!important;
	}
	

}

#regalin p{
    font-weight: 600;
    margin-top: 2%;
    font-size: 0.9em;
    padding-left: 3%;
}
#regalin input{
    margin: 3% 0;
    margin-left: 20%;
    cursor: pointer;
}
#regalin label{
    cursor: pointer;
}



</style>

<script>



$( document ).ready(function() {



// console.log(exUrl)
// console.log(history.pushState)
	 abreMod();

$('#ppl-static').click(function () {
	cierraMod();
});



	$('#cerrarModal').click(function () {
		cierraMod();
	    
	    
	});
	

	$('#fondoModal').on('click', function(e) {
  		if (e.target !== this)
    		return;
  
 			cierraMod();
		});


	function abreMod(){
		$('body').css({'overflow-y':'hidden'})
		$('#fondoModal').css({'display':'block','opacity':'1'})

		setTimeout(function() {

			$('#fondoModal>div').css({'transform':'scale(0.9)'})

		}, 150)

	};
	
	function cierraMod(){
		$('body').css({'overflow-y':'auto'})
		$('#fondoModal>div').css({'transform':'scale(0)'})
		
		setTimeout(function() {
			$('#fondoModal').css({'display':'none','opacity':'0'})
		}, 150)
	};




}); //Termina el documentReady


function verTerminos(){
	window.open ("http://lengaswear.com/es/terminos", "Terminos");
}


function proceder(){

    //  Javascript de carrito comentado por el momento
    var carritoObj = localStorage.getItem('carrito')
    var carritoObj = JSON.parse(carritoObj)
    $('.default').text('VERIFYING...')


let button = $('.order');

if(!button.hasClass('animate')) {
    button.addClass('animate');
    setTimeout(() => {
        button.removeClass('animate');
    }, 6200);
}



    if( Object.keys(carritoObj).length > 0){
    
    
    var carrito_final = [];
    var total = 0;
    for (var n = 0; n < Object.keys(carritoObj).length; n++){
    
    var key = Object.keys(carritoObj)[n];
    var modelo = carritoObj[key];
    
    var cant = modelo.cantidad
    var precio = modelo.precio
    var precio = precio.replace("$ ", "");
    var subTot = cant * precio;
    total += cant * precio;
    
    var producto;
    window['producto'+n] = modelo.nombre + ' - '+modelo.precio+' - ' + modelo.cantidad
    window['producto'+n] = modelo.nombre + ' - '+modelo.precio+' - ' + modelo.cantidad
    
    for (let ki = 0; ki < cant; ki++) {
        var modelo_nombre = modelo.nombre[0].toUpperCase() + modelo.nombre.slice(1)
        carrito_final.push(modelo_nombre)
    }
    
    
    }
    
    
    };
    
    console.log(carrito_final, total)


    console.log('Breadcrumb #1')

    var nombre = $('#nombreP').val();
    console.log('nombre: ' + nombre);
    var mail = $('#mailP').val();
    var mail = $.trim(mail);
    console.log('mail: ' + mail);
    var telefono = $('#telefonoP').val();
    console.log('telefono: ' + telefono);
    var country = $('#country').val();
    var street = $('#street').val();
    var streetNumber = $('#street-number').val();
    var floor = $('#floor').val();
    var city = $('#city').val();
    var district = $('#district').val();
    var zipCode = $('#zip-code').val();
    var fueguinoAlert = $('#fueguinoAlert').val();
    console.log('fueguinoAlert: ' + fueguinoAlert);
    var haceCuanto = $('#haceCuantoP').val();
    console.log('haceCuanto: ' + haceCuanto);
    var fuente = $('#fuenteP').val();
    console.log('fuente: ' + fuente);
    var porque = $('#porque').val();
    var cuponstatus = $('#cuponstatus').val();

	
    console.log('Breadcrumb #2');

    if((mail && haceCuanto && fuente) != ''){
        // $('#enviarCorpo').html('PROCESANDO...');
        console.log('antes de ajax')
        $.ajax({
            url:'registrarPedido.php',
            method:'POST',
            cache: false,
            data:{
            	nombre:nombre,
                mail:mail,
                telefono:telefono,
                country: country,
                street:street,
                streetNumber:streetNumber,
                floor:floor,
                city:city,
                district:district,
                zipCode:zipCode,
                haceCuanto:haceCuanto,
                fuente:fuente,
                order_value:total,
                porque:porque,
                carrito:carrito_final,
                cuponstatus:cuponstatus

            },
            dataType:'text',
            success:function(data){
            	$(".completar").each(function() {  
				$(this).removeClass('completar');
				
				});
				
				// localStorage.setItem('carrito','')

            // 	$('#enviarCorpo').html('PERFECTO!');
            	
                console.log(data)

                // Pushea un GET para que Facebook tome la conversion
             	history.pushState({},"Checkout Completado",'?checkoutCompletado=1');

                var str = data;

                if(carrito_final.includes('Quemanta')){
                	console.log('Boton de pago de Quemanta')
                	$('#enviarCorpo').css('display', 'none');
                	$('#ppl-static div').html('<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="22FDFBKECS4YY"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1"></form>')
                }else if(carrito_final.includes('Jauke')){
                	console.log('Boton de pago de Jauke')
                	$('#enviarCorpo').css('display', 'none');
                	$('#ppl-static div').html('<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="SQ2HTMCNC9HZY"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1"></form>')
                }else if(carrito_final.includes('Tesh')){
                	console.log('Boton de pago de Tesh')
                	$('#enviarCorpo').css('display', 'none');
                	$('#ppl-static div').html('<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="ZDNHUDF39RKTE"><input type="image" src="https://www.paypalobjects.com/es_XC/AR/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1"></form>')
                }else if(carrito_final.includes('Mahai')){
                	console.log('Boton de pago de Mahai')
                	$('#enviarCorpo').css('display', 'none');
                	$('#ppl-static div').html('<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="QYZDG3SNF3KLW"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1"></form>')
                }
                
                
                $('#inputs').slideUp()
                $('#tits').slideUp()
                $('#fondoModal>div').addClass('sentMargin')

                // Comentado hasta arreglar el checkout con el SDK
                // Extrayendo el link de pago de la data generada
				// linkPago = str.substring(str.indexOf("URLPAGO:") + 8);
				// console.log(linkPago);  
    //             setTimeout(() => {
    //                 window.location = linkPago;
    //             }, 2500);
            }
            
        });
   

    }else{
    	// console.log('completa campos vacios')
    	// alert('Completar campos vacÃƒÂ­os!');
		$('.default').text('PROCEED')
		$('.success').text('FIELDS MISSING :/')
		$('.success svg').css('display','none')
		setTimeout(() => {
// 			$('.success').text('REDIRECTING...')
			$('.success svg').css('display','block')
		}, 5200);

    	$(".inputes").each(function() {
    	if($(this).val()==''){ 

    	// Evitando que se le aplique a los campos opcionales
    	if(this.id!='floor' && this.id!='district'){ 
		$(this).addClass('completar');
		}


		}else{
		$(this).removeClass('completar');
		}
		});
    }

}


</script>