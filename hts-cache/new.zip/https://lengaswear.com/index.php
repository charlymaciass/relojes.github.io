
<!DOCTYPE html>

<html lang="es">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

		<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-TMXKLTQ');</script>
	<!-- End Google Tag Manager -->
    <!-- Hotjar Tracking Code for lengaswear.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1298492,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
	

	<title>Lengas | Relojes de madera artesanales</title>
    <meta name="keywords" content="Relojes, relojes de madera, artesanales, relojes de madera artesanales, lengas, Lengas">
    <meta name="author" content="Lengas">
	<meta name="description" content="Fabricamos piezas de tiempo artesanales, con materia prima Austral. Por cada reloj vendido, estamos plantando un árbol de Lenga en áreas degradadas de la Patagonia Argentina.">		

	<meta name="robots" content="index,follow"/>

	<meta name="googlebot" content="index,follow"/>

	<!-- no scalable -->		 

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<!-- Fav Icon -->

	<link rel="icon" href="imgs/favicon.png" type="image/x-icon"/>

	<link rel="shortcut icon" href="imgs/favicon.png" type="image/x-icon"/>

	<!-- que link prioriza google -->

	<link href="http://lengaswear.com" rel="canonical">

	<!-- Redes sociales -->

    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Lengas">
    <meta property="og:title" content="Relojes de madera artesanales | Lengas" />
    <meta property="og:description" content="Fabricamos piezas de tiempo artesanales, con materia prima Austral. Por cada reloj vendido, estamos plantando un árbol de Lenga en la Patagonia." />
	<meta property="og:image" content="https://lengaswear.com/relojes/fotos/guayubira-vetas.jpg">
	<meta property="og:url" content="http://lengaswear.com"/>
    <meta property="og:image:type" content="image/jpg">
    <!--<meta property="og:image:width" content="1024">-->
    <!--<meta property="og:image:height" content="1024">-->
    <!--<meta property="fb:app_id" content="">-->









	<link rel="stylesheet" type="text/css" media="(min-width: 800px)" href="css/home.css" />

	<link rel="stylesheet" type="text/css" media="(max-width: 799px)" href="css/homeMobile.css?refrescate=1" />
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!--<script src="home.js"></script>-->
</head>

<body style="background-color: #fbf8f8">

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TMXKLTQ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->



<style>
#boton-cart{
    display: block;
    z-index: 999;
    position: fixed;
    top: 5%;
    right: 0%;
    transition: .2s;
}
#boton-cart>div{
    position: relative
}
#img-cont{
    border-bottom-left-radius: 55px;
    border-top-left-radius: 55px;
    background-color: #f0f0f0;
    position: relative;
    /*border: 0.5px solid black;*/
    box-shadow: 0px 4px 8px 1px rgba(0,0,0,0.2);
    border-right: none;
}
#santa-hat{
    position: absolute;
    width: 30%;
    transform: rotateY(180deg);
    right: 15%;
    top: 0%
}
#cartIcon{
    height: 5vh;
    padding: 1.5vh 2vh 1.3vh 2.2vh;
    transition: .2s;
}
#boton-cart:hover{
    transform: scale(1.15) translateX(-5%); 
}
#cantidad{
    position: absolute;
    padding: 6% 11%;
    left: -2%;
    top: -2%;
    background: red;
    border-radius: 55px;
    z-index: 999;
}
#cantidad>p{
    color: white;
    font-weight: 600;
    font-size: 0.7rem;
    text-align: center
}


</style>

<a href="/carrito" id='boton-cart'>
<div>
    <div id="cantidad">
        <p></p>
    </div>
    <div id="img-cont">
            <!--<img id="santa-hat" src="https://lengaswear.com/imgs/santa-hat.svg" alt="">-->
            <img id="cartIcon" src="https://lengaswear.com/imgs/shopping-cart.svg" alt="">
    </div>
</div>
</a>

<script>
$( document ).ready(function() {
    


var carritin = 0;
$('#cantidad>p').text(carritin)

// Limpiador de carrito
    // var carrito = {};
    // var carrito = JSON.stringify(carrito);
    // localStorage.setItem("carrito", carrito);


var carritoObj = localStorage.getItem('carrito')

var carritoObj = JSON.parse(carritoObj)

if(Object.keys(carritoObj).length > 0){
    var carritin = Object.keys(carritoObj).length
}

$('#cantidad>p').text(carritin)


});
</script><style>
	
	#region{
    position: fixed;
    z-index: 40000;
    display: flex;
    justify-content: center;
    /* align-items: center; */
    background-color: #f7f7f7;
    height: 100%;
    width: 100%;
    /* left: 5%; */
    /* top: 5%; */
    /* padding: 5%; */
    border-radius: 4px;
    box-shadow: 1px 1px 9px #b3b3b3;
	}

	#inner-reg{
		margin-top: 6%;
	}

	#reg-tit{
	font-size: 2em;
    text-transform: uppercase;
    margin-bottom: 25%;
    font-family: vincent;
    text-align: center;
	}

	.region{
	font-size: 1.8em;
    color: gray;
    background-color: white;
    border-radius: 4px;
    padding: 8px 20px;
    display: flex;
    margin-bottom: 10px;
    align-items: center;
    text-transform: uppercase;
    cursor: pointer;
	}

	.region:hover{
		box-shadow: 1px 1px 9px #b3b3b3;

	}

	.region img{
		margin-right: 8px;
	}

	#ima-pepa{
    text-align: center;
    margin-bottom: 6px;
	}

	/*Clases para mobile*/
	@media only screen and (max-width: 600px) {
	  
	  #inner-reg{
	  	margin-top: 24%;
	  }


	}

</style>

<div id="region">
	
	<div id="inner-reg">
		
		<div id="ima-pepa"><img src="imgs/Imagotipo-Pepa.png" height="30px" alt=""></div>
		<div id="reg-tit">Region</div>

		<div>
			
			<div class="region" onclick="takeme('ARG')"><img src="imgs/argentina.svg" height="30px" alt="">Argentina</div>
			<div class="region" onclick="takeme('LATAM')"><img src="imgs/latin.svg" height="30px" alt="">Latin America</div>
			<div class="region" onclick="takeme('ES')"><img src="imgs/spain.svg" height="30px" alt="">España</div>
			<div class="region" onclick="takeme('EU')"><img src="imgs/europe.svg" height="30px" alt="">Europe</div>
			<div class="region" onclick="takeme('US')"><img src="imgs/united-states.svg" height="30px" alt="">United States</div>

		</div>

	</div>

</div>

<script>
	
function takeme(REG){
	if(REG=='EU' || REG=='US'){
		window.location = 'https://lengaswear.com/en';
	}else if(REG=='ES'){
		window.location = 'https://lengaswear.com/es';
	}else if(REG == 'LATAM'){
	    window.location = 'https://lengaswear.com/latam';
	}else{
		var region_modal = document.getElementById('region');
		region_modal.style.display = 'none';
	}
}

</script>


<div id="envioGratarola">

	<div class="cont80x100">

		<p>ENVÍO Y DEVOLUCIÓN GRATIS EN TODAS LAS COMPRAS DE ARGENTINA</p>

		<span>x</span>

	</div>

</div>

<style>

/* Para compu */

@media only screen and (min-width: 799px) {

#seccion-covid{

	padding: 10vh 10% 7vh 10%;

	background: black;

}

#seccion-covid button{

	color: rgb(255,255,255);

    margin: auto;

    display: block;

    font-size: .85em;

    font-weight: 700;

    margin-top: 10%;

    padding: 7px 36px;

    border-radius: 55px;

    background: #bc8c3e;

    border: 2px #bc8c3e solid;

    /* opacity: 0; */

    transition: .2s cubic-bezier(.19,.48,.09,1);

    outline: none;

	cursor: pointer;

}

#seccion-covid button:hover{

	background: none

}

#seccion-covid img{

	width: 2vw;

	width: 24px;



	display: block;

	margin: 1% auto;

	filter: invert(.8)

}

#seccion-covid h3{

	color: #bc8c3e;

    font-family: 'Vincent';

    font-size: 2em;

    font-weight: 300;

	width: 85%;

	margin: 5% 0;

}

#seccion-covid p{

	color: white;

    font-weight: 500;

    margin: 5% 0;

}	

}





/* Para celu */

@media only screen and (max-width: 800px) {

#seccion-covid{

	padding: 10vh 10% 7vh 10%;

	background: black;

}

#seccion-covid button{

	color: rgb(255,255,255);

    margin: auto;

    display: block;

    font-size: 1em;

    font-weight: 700;

    margin-top: 10%;

    padding: 7px 36px;

    border-radius: 55px;

    background: #bc8c3e;

    border: 2px #bc8c3e solid;

    /* opacity: 0; */

    transition: .2s cubic-bezier(.19,.48,.09,1);

    outline: none;

}

#seccion-covid button:hover{

	background: none

}

#seccion-covid img{

	width: 8vw;

	display: block;

	margin: 1% auto;

	filter: invert(.8)

}

#seccion-covid h3{

	color: #bc8c3e;

    font-family: 'Vincent';

    font-size: 2em;

    font-weight: 300;

	width: 85%;

	margin: 5% 0;

}

#seccion-covid p{

	color: white;

    font-weight: 500;

    margin: 5% 0;

}



}

</style>



<div id="seccion-covid" style="display: none;">

	<div class="cont80x100">

		<img src="https://lengaswear.com/imgs/favicon.png" alt="">

		<h3>Al virus lo frenamos entre todos.</h3>

		<p>La propagación del COVID-19 nos afecta a todos. Es por eso que frenamos nuestras ventas temporalmente. Vamos a estar retomando sus pedidos pendientes cuando levanten las medidas de cuarentena obligatoria. Nuestra produccion se ve sujeta a esto. Mientras tanto, tenemos listas de esperas abiertas para cada reloj.</p>
		
		<p>Fuera de lo que es venta de relojes, pueden contar con nosotros en caso de que necesiten hablar con alguien...la cuarentena puede tornarse aburrida :)</p>

		<p>A mantener una actitud positiva!</p>

		<a href="#relojes-home-cont">

			<button>VER MODELOS</button>

		</a>

	</div>

</div>

<header id="portada-home">

<img src="../imgs/miniLogo.png" alt="logo Lengas">

<h4>- PIEZAS DE TIEMPO -</h4>

<h2>ArtesaNales</h2>

<nav>

	<ul>

		<li><a href="#shop">RELOJES</a></li>

		<li><a href="#proceso">PROCESO</a></li>

		<li><img src="imgs/divisor.png" width="50px" alt="menu divider"></li>

		<li><a href="#impacto">IMPACTO</a></li>

		<li><a id="somosAncla" href="#somos">SOMOS</a></li>

	</ul>

</nav>
<div>
	<a href="#relojes-home-cont">
		<p>VER RELOJES</p>
		<img src="relojes/imgs/down-arrow.svg" alt="">
	</a>
</div>
</header>
<div id="shop"></div>
<div id="relojes-home-cont">
<div>
    <!-- Titulo -->
    <div class="titulo-prds-home">
		<h5>- La Naturaleza Viene en Colores -</h5>
		
		<!-- Haciendo un include de la parte navidenia -->
		<!-- Agregado para la preventa navidenia  -->
		<style>
			.regalito{
			    margin: 0px 5px;
    			transform: translateY(4px);
			}

			#principales-navidad{
				border: 2px solid #e83333;
			    color: #e83333;
			    width: 328px;
			    padding: 0px 2px;
			    border-radius: 24px;
			    font-family: montserrat;
			    font-size: 0.6em;
			    line-height: 0px;
			    letter-spacing: 0;
			    font-weight: bold;
			    padding-bottom: 10px;
			    text-transform: uppercase;
    			text-align: center;
			}
			
			#navidad-prds{
    				display: flex;
    				width: 100%;
    				justify-content: center;
    				align-items: center;
    				margin-top: 10px;
    	    }

			.i-nav{
				background-color: #bf1b1b;
			    color: white;
			    padding: 4px 10px 6px 11px;
			    border-radius: 13px;
			    font-size: 0.7em;
			    text-align: center;
			    transform: translate(-17px, -12px) scale(0.7);
			    font-family: montserrat;
			    font-weight: bold;
			    text-transform: lowercase!important;
			    cursor: pointer;
			}

			.nav-msg{
				    font-family: montserrat;
                    letter-spacing: 0;
                    font-size: 0.8em;
                    width: 282px;
                    text-align: left;
                    position: absolute;
                    text-transform: none;
                    background-color: rgba(255, 255, 255, 0.95);
                    border-radius: 10px;
                    padding: 10px;
                    transform: translate(319px, -12px);
                    z-index: 3;
                    opacity: 0;
                    transition: opacity 0.2s;
			}

			.i-nav:hover + .nav-msg{
				opacity: 1;
			}

			#nav-count{
				font-size: 0.6em;
			    font-family: montserrat;
			    letter-spacing: 0;
			    font-weight: bold;
			    color: #e83333;
			    margin-top: 5px;
			}
			
			/*PARA MOBILE*/
			@media only screen and (max-width: 700px) {
				  .nav-msg {
				    transform: translate(-14px, -12px);

				  }
				  
    		    #navidad-prds{
    				display: flex;
    				width: 106%!important;
    				justify-content: center;
    				align-items: center;
    				margin-top: 10px;
    			}
			}

		</style>
		<div id="navidad-prds">
			<div id="principales-navidad"><span>Pre-Venta Abierta<img src="imgs/gift.svg" height="20px" class="regalito"></span><span> - UNIDADES LIMITADAS</span></div><span class="i-nav">i</span>
			<span class="nav-msg">Ante una elevada demanda y techos en la produccion, he aqui, una nueva pre-venta. Es la mejor forma que encontramos para que puedas reservar tu unidad y lograr un consumo mas responsable entregando contra-pedido 📦<span>	
		</div>
			<div id="nav-count">Despachando todo a partir del 10 de Agosto</div>		
		
		<!-- Javascript para el countdown  -->
		<script>

// 		var endDate = new Date(2019, 11, 18, 21).getTime();

// 		var timer = setInterval(function() {

// 		    let now = new Date().getTime();
// 		    let t = endDate - now;
		    
// 		    // console.log(now)
// 		    // console.log(endDate)

// 		    if (t >= 0) {
		    
// 		        let days = Math.floor(t / (1000 * 60 * 60 * 24));
// 		        let hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
// 		        let mins = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
// 		        let secs = Math.floor((t % (1000 * 60)) / 1000);
		    
// 		        document.getElementById("days").innerHTML = days +
// 		        "<span> Dias </span>";
		    
// 		        document.getElementById("hours").innerHTML = ("0"+hours).slice(-2) +
// 		        "<span> Horas </span>";
		    
// 		    } else {

// 		        document.getElementById("relaunch").innerHTML = "The countdown is over!";
		    
// 		    }
		    
// 		}, 1000);

		</script>
		<!-- Termina agregado para la preventa navidenia -->		
	</div>
    <!-- Relojes Contenedor -->
    <div id="relojes-cont-prd-home">
        <!-- Reloj contenedor individual -->
		<a href="relojes/quemanta">
		<div class="reloj-cont-prd-home">
            <div id="lenga" class="prd-bg"></div>
            <!-- Textos -->
            <div class="textos-prd-home">
                <div class="precio-prd-home">$
                <!--<span style="text-decoration: line-through; opacity: 0.8">6750</span> -->
                6750</div>
                <div class="nombre-prd-home">Quemanta</div>
                <div class="btn-prd-home"><button>Comprar</button></div>
            </div>
		</div>
		</a>
        <!-- Reloj contenedor individual -->
		<a href="relojes/tesh">
		<div class="reloj-cont-prd-home">
            <div id="guayubira" class="prd-bg"></div>       
            <!-- Textos -->
            <div class="textos-prd-home">        
                <div class="precio-prd-home">$
                <!--<span style="text-decoration: line-through; opacity: 0.8">7400</span> -->
                7400</div>
                <div class="nombre-prd-home">Tesh</div>
                <div class="btn-prd-home"><button>Comprar</button></div>
            </div>
		</div>
		</a>
        <!-- Reloj contenedor individual -->
		<a href="relojes/jauke">
		<div class="reloj-cont-prd-home">
            <div id="cancharana" class="prd-bg"></div>
            <!-- Textos -->
            <div class="textos-prd-home">
                <div class="precio-prd-home">$
                <!--<span style="text-decoration: line-through; opacity: 0.8">7900</span> -->
                7900</div>
                <div class="nombre-prd-home">Jauke</div>
                <div class="btn-prd-home"><button>Comprar</button></div>
            </div>
		</div>
		</a>
        <!-- Reloj contenedor individual -->
		<a href="relojes/mahai">
		<div class="reloj-cont-prd-home">
            <div id="moradillo" class="prd-bg"></div>
            <!-- Textos -->
            <div class="textos-prd-home">
                <div class="precio-prd-home">$
                <!--<span style="text-decoration: line-through; opacity: 0.8">9999</span> -->
                9900</div>
                <div class="nombre-prd-home">Mahai</div>
                <div class="btn-prd-home"><button>Comprar</button></div>
            </div>
		</div>
		</a>
    </div>
</div>
</div>

<!-- </div> -->


<div id="prd-page"></div>


<div id="proceso"></div>

<section id="procesoCont">

	<div class="cont80x100">

		<h4>-PROCESO-</h4>

		<div id="listaProceso">

			<article>

				<div class="fotoCont">

					<img src="imgs/step1.jpg" width="100%" alt="parte1 proceso de reloj artesanal">

				</div>

				<div class="descCont">

					<span>.01</span>

					<h5>EXTRAEMOS</h5>

					<span>ARGENTINA, MULTIPLES REGIONES</span>

					<p>El comienzo del ciclo productivo se origina en distintas regiones forestales de la Argentina, mayormente dentro de la Patagonia. Como por ejemplo los bosques de Lenga de Tierra del Fuego donde se extrae la materia prima para aprovechar la madera noble que tienen para ofrecer.</p>

				</div>

			</article>

			<article>

				<div class="fotoCont">

					<img src="imgs/step2.jpg" width="100%" alt="parte1 proceso de reloj artesanal">

				</div>

				<div class="descCont">

					<span>.02</span>

					<h5>PROCESAMOS</h5>

					<span>CASEROS, GBA</span>

					<p>La madera es procesada en tablones de diferentes dimensiones y espesores por sus diversos usos en las distintas industrias. Recibimos las tablas en bruto y con ayuda de un luthier cepillamos las maderas llevándolas al espesor deseado.</p>

				</div>

			</article>

			<article class="todaviaNo">

				<div class="fotoCont">

					<img src="imgs/step3.jpg" width="100%" alt="parte1 proceso de reloj artesanal">

				</div>

				<div class="descCont">

					<span>.03</span>

					<h5>MECANIZAMOS</h5>

					<span>SAAVEDRA, CABA</span>

					<p>Teniendo los tablones ya cepillados en espesores de 10mm y 5mm, empieza el proceso de mecanizado en CNC. Con la ayuda de máquinas plasmamos los rasgos generales de la pieza, a partir de nuestro diseño 3D.</p>

				</div>

			</article>

			<article class="todaviaNo">

				<div class="fotoCont">

					<img src="imgs/step4.1.jpg" width="100%" alt="parte1 proceso de reloj artesanal">

				</div>

				<div class="descCont">

					<span>.04</span>

					<h5>TORNEAMOS</h5>

					<span>GRAL. PACHECO, GBA</span>

					<p>Estas piezas son trasladadas a nuestro taller en Zona Norte donde torneamos cada una de ellas para darles un mejor lijado, definición de bordes, y descubrir por completo la hermosa veta de la madera.</p>

				</div>

			</article>

			<article class="todaviaNo">

				<div class="fotoCont">

					<img src="imgs/step5.1.jpg" width="100%" alt="parte1 proceso de reloj artesanal">

				</div>

				<div class="descCont">

					<span>.05</span>

					<h5>TEÑIMOS</h5>

					<span>GRAL. PACHECO, GBA</span>

					<p>Ya torneados los relojes, procedemos a darle el acabado en aceites vegetales. Es muy importante que el paso previo haya sido llevado a cabo bien para una correcta absorción de los aceites en la madera.</p>

				</div>

			</article>

			<article class="todaviaNo">

				<div class="fotoCont">

					<img src="imgs/step6.1.jpg" width="100%" alt="parte1 proceso de reloj artesanal">

				</div>

				<div class="descCont">

					<span>.06</span>

					<h5>ENSAMBLAMOS</h5>

					<span>GRAL. PACHECO, GBA</span>

					<p>Finalizado el tiempo de secado, la pieza está lista para cobrar vida. Se coloca el movimiento (Cuarzo Japones Y121E) junto con las agujas. Tras colocar la corona se selecciona el calibre del cristal que mejor se adecúa. Un pequeño click al presionar la corona y nace un nuevo Lenga.</p>

				</div>

			</article>

		</div>

	</div>



<div id="verMasProc">

	<p>VER MAS</p>

	<img src="imgs/downArrow.svg" width="20px" alt="ver mas del proceso">

</div>

</section>





<div id="impacto"></div>

<div id="somos"></div>

<aside>

	<div class="cont80x100">

		<h4>-FIN DEL PROCESO-</h4>

		<h2>Nace un Lenga</h2>

		<p>En conjunto con la fundacion ReforestArg estamos ayudando a restaurar areas degradadas de Patagonia.<br>Todos los meses destinamos un porcentaje de nuestros ingresos para contribuir con el programa de restauración ecológica de los bosques nativos degradados.<br>¿Te interesa conocer mas acerca de nosotros y el proyecto detras de la marca?</p>

		<div id="somosHidden">

			<div id="videito">

				<video style="outline:none; border-radius:5px" src="videos/Horizontal.mp4" width="100%" controls></video>

			</div>

			<p>

			Luego de un año de diseños, prototipos y reinvenciones del producto, logramos materializar nuestra idea. Fueron 12 meses en los cuales se puso a prueba y debate hasta el más ínfimo detalle. Un período de disconformidad que parecía no terminar. Todo en pos de adaptar la funcionalidad al diseño pretendido.

			<br><br>

			Así se forjó la marca Lengas. Con prueba, error e incontables viajes en bondi por GBA. Hoy vendiendo un producto artesanal y con sus materiales obtenidos en Argentina. Un reloj que mantiene el cuadrante, bisel y caja unidos en una pieza pura e íntegra. Acompañado de un sistema que nos permite devolver un árbol por cada venta.

			<br><br>

			Alcanzamos el público que buscábamos. Uno al que realmente le interesa lo que ofrecemos y los valores detrás de la marca.

			<br><br>

			Amamos cada parte del proceso. Desde la selección de las tablas en la maderera hasta el ensamblado, comercialización, y envío del producto. Somos partícipes activos en cada una de las etapas. Vernos forzados a aprender cada una de ellas, nos da pie a identificar el talento necesario para llevar a cabo las partes del proceso productivo y de a poco ir ampliando nuestro equipo.

			</p>

		</div>

		<div id="verSomos">

			<p>VER MAS</p>

			<img src="imgs/downArrow.svg" width="20px" alt="ver mas del proceso">

		</div>

	</div>	

</aside>



<section>

	<div class="cont80x100">

		<div id="shopNow">

			<!--<img src="imgs/franjaShopNow2.jpg" alt="relojes artesanales de madera">-->

			<h2>Uno con la NaturaLeza</h2>

			<a href="#shop"><h6>shop now</h6></a>

		</div>

		<div id="galeria1">

			<div id="foto1"></div>

			<div id="foto2"></div>

			<div id="foto3"></div>

			<div id="foto4"></div>

		</div>

	</div>

</section>



<style>



@media only screen and (min-width: 600px) {

.slide{

	opacity: 1!important;

	transform: translateX(0)!important;

}



#seccionNuevaLetra{

	background-image: url('imgs/franjaNewsletter.jpg');

  	background-size: cover;

  	background-position: center;

  	background-repeat: no-repeat;

  	padding: 3% 0;

  	z-index: 40;

  	position: relative;

}



#seccionNuevaLetra h2{

	color: white;

	font-size: 4em;

	text-shadow: 1px 1px 2px #111111;

	width: 70%;

}

#seccionNuevaLetra p{

	color: white;

	font-size: 1em;

	margin: 3% 0;

	width: 70%;

}

#seccionNuevaLetra form>input{

	background: transparent;

	border: none;

	color: white;

	font-family: 'Vincent';

	outline: none;

	letter-spacing: 1px;

	font-size: 1.2em;

	padding: 3px 0;

	border-bottom: 2px white solid;

	margin-right: 10px;

}

#seccionNuevaLetra input::placeholder{

	color: white;

	font-family: 'Vincent';

	letter-spacing: 1px	;

	font-weight: lighter;

}

#enviarNews{

	border: none;

	background: transparent;

	display: block;

	width: 5vh;

	height: 5vh;

	cursor: pointer;

/*	background: rgba(255,0,0,0.3);*/

	position: absolute;

	transform: translateY(-100%);

	outline: none;

}

#seccionNuevaLetra form>div{

	display: inline-block;

	width: 5vh;

	height: 5vh;

	position: relative;

}



#tickCont{

	transition: all .8s;

	transition-timing-function: ease-in-out;

}



#tickSolo{

	opacity: 0.6;

	transition: .2s;

}

#seccionNuevaLetra form>div:hover #tickSolo{

	opacity: 1;

}



}





@media only screen and (max-width: 600px) {

	
.slide{

	opacity: 1!important;

	transform: translateX(0)!important;

}


#seccionNuevaLetra{

	background-image: url('/imgs/franjaNewsletter.jpg');

  	background-size: cover;

  	background-position: center;

  	background-repeat: no-repeat;

  	padding: 10% 0;

  	z-index: 40;

  	position: relative;

}



#seccionNuevaLetra h2{

	color: white;

	font-size: 2.5em;

	text-shadow: 1px 1px 2px #111111;

}

#seccionNuevaLetra p{

	color: white;

	font-size: 1em;

	margin: 3% 0;

}

#seccionNuevaLetra form>input{

	background: transparent;

	border: none;

	color: white;

	font-family: 'Vincent';

	outline: none;

	letter-spacing: 1px;

	font-size: 1.2em;

	padding: 3px 0;

	border-bottom: 2px white solid;

	margin-right: 10px;

}

#seccionNuevaLetra input::placeholder{

	color: white;

	font-family: 'Vincent';

	letter-spacing: 1px	;

	font-weight: lighter;

}

#enviarNews{

	border: none;

	background: transparent;

	display: block;

	width: 5vh;

	height: 5vh;

	cursor: pointer;

	/*background: rgba(255,0,0,0.3);*/

	position: absolute;

	transform: translateY(-100%);

	outline: none;

}

#seccionNuevaLetra form>div{

	display: inline-block;

	width: 5vh;

	height: 5vh;

	position: relative;

}



#tickCont{

	transition: all .8s;

	transition-timing-function: ease-in-out;

}



#tickSolo{

	opacity: 0.6;

	transition: .2s;

}

#seccionNuevaLetra form>div:hover #tickSolo{

	opacity: 1;

}



}

</style>


<div id="newsletter"></div>
<div id="seccionNuevaLetra">

	<div class="cont80x100">

		<h2>suscribiTe A Nuestro Newsletter</h2>

		<p>Mantenete informado acerca de nuevos lanzamientos y novedades sobre el impacto que nuestro proyecto está generando.</p>

		<form>

			<input type="text" placeholder="NOMBRE" id="nombre"><br>

			<input type="mail" placeholder="MAIL" id="mail">

			<div>

				<div id="tickCont">

					
<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" width="100%">
<g>
	<g>
		<path id="tickSolo" d="M497.36,69.995c-7.532-7.545-19.753-7.558-27.285-0.032L238.582,300.845l-83.522-90.713    c-7.217-7.834-19.419-8.342-27.266-1.126c-7.841,7.217-8.343,19.425-1.126,27.266l97.126,105.481    c3.557,3.866,8.535,6.111,13.784,6.22c0.141,0.006,0.277,0.006,0.412,0.006c5.101,0,10.008-2.026,13.623-5.628L497.322,97.286    C504.873,89.761,504.886,77.54,497.36,69.995z" fill="#FFFFFF"/>
	</g>
</g>
<g>
	<g>
		<path d="M492.703,236.703c-10.658,0-19.296,8.638-19.296,19.297c0,119.883-97.524,217.407-217.407,217.407    c-119.876,0-217.407-97.524-217.407-217.407c0-119.876,97.531-217.407,217.407-217.407c10.658,0,19.297-8.638,19.297-19.296    C275.297,8.638,266.658,0,256,0C114.84,0,0,114.84,0,256c0,141.154,114.84,256,256,256c141.154,0,256-114.846,256-256    C512,245.342,503.362,236.703,492.703,236.703z" fill="#FFFFFF"/>
	</g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>

				</div>

				<input id="enviarNews" type="submit" value="" onclick="suscribirse()">

			</div>

		</form>



		<!-- SE MUESTRA SI EL SUSCRIPTOR ES SUSCRITO CON EXITO -->

		<div id="exito" style="margin-top: 10px; font-family: vincent; font-weight: bold; transform: translateX(-50px); transition: transform 0.4s, opacity 0.2s; opacity: 0; color: #1e1e1e;">Suscrito con exito!</div>



	</div>

</div>



<script>

function suscribirse(){

    $('#enviarNews').submit(event.preventDefault());

    console.log('aca')

    var nombre = $('#nombre').val();

    var mail = $('#mail').val();

   

    if($.trim(mail) != ''){

        $.ajax({

            url:'suscribir.php',

            method:'POST',

            cache: false,

            data:{

                nombre:nombre,

                mail:mail},

            dataType:'text',

            success:function(data){

                console.log(data);

                $('#nombre').val('');

                $('#mail').val('');

               // Pushea un GET para que Facebook tome la conversion
                history.pushState({},"Suscrito",'?suscripcion=1');

                var exito = $('#exito');

                exito.html('Suscrito con exito! :)');

                exito.css('display', 'block');

                exito.addClass('slide');
                jabon = document.getElementById('jabon')
                jabon.innerText = String.fromCodePoint(0x1F9FC);


                

            }

        });

    }

   

}



</script><div id="testimonios">
	<!-- 
	use the left and right arrow keys on your keyboard or just swipe left and right on your smart phone to interact with the slider
-->

<section id="testim" class="testim">
            <div class="wrap">

                <span id="right-arrow" class="arrow right fa fa-chevron-right"></span>
                <span id="left-arrow" class="arrow left fa fa-chevron-left "></span>
                <ul id="testim-dots" class="dots">
                    <li class="dot active"></li><!--
                    --><li class="dot"></li><!--
                    --><li class="dot"></li>
                    <li class="dot"></li><!--
                    --><!-- <li class="dot"></li> -->
                </ul>
                <div id="testim-content" class="cont">

                    <div>
                        <div class="img"><img src="imgs/tony.jpg" alt=""></div>
                        <h5>Tony Kissner - Necochea</h5>
                        <p>"Es hermoso y único. Llegó impecable. Desde la experiencia del desempaquetado hasta el reloj en sí, muy lindo."</p>                    
                    </div>
                    
                   <div class="active">
                        <div class="img"><img src="https://image.ibb.co/hgy1M7/5a6f718346a28820008b4611_750_562.jpg" alt=""></div>
                        <h5>Andrea Campos - Tandil, Buenos Aires</h5>
                        <p>"Me encanta el diseño puro y limpio. No suelo comprar por internet pero el proceso fue super fácil. Muy contenta con mi reloj! :)"</p>                    
                    </div>
                    
                    <div>
                        <div class="img"><img src="imgs/martin-lobianco.jpg" alt=""></div>
                        <h5>Martin Lo Bianco - Santa Fe</h5>
                        <p>"El reloj está muy bueno, bien hecho y lo mejor es que está hecho acá! Mucha gente me lo ve y se preguntan cómo lo compre!"</p>                    
                    </div>


                    <div>
                        <div class="img"><img src="imgs/martina-andrade.jpg" alt=""></div>
                        <h5>Martina Andrade - Ushuaia, Tierra del fuego</h5>
                        <p>"El reloj es divino. Me parece super fino y delicado. Y, lo que más me hace apreciarlo es la sencillez."</p>                    
                    </div>
                
                    <!-- <div>
                        <div class="img"><img src="https://image.ibb.co/kL6AES/Top_SA_Nicky_Oppenheimer.jpg" alt=""></div>
                        <h5>Erik Gonzalez - El Bolson, Rio Negro</h5>
                        <p>"Muy lindos y especialmente comodos por el poco peso. Acompañado de semejante propuesta ambiental 👌👌."</p>                    
                    </div> -->

                   <!--  <div>
                        <div class="img"><img src="https://www.diariogol.com/uploads/s1/64/71/53/0/leo-messi_15_970x597.jpeg" alt=""></div>
                        <h5>Leo Messi - Barcelona, España</h5>
                        <p>"Precio?"</p>                    
                    </div> -->

                </div>

            </div>
    </section>


</div>
<style>
	/*@import url(//cdn.rawgit.com/rtaibah/dubai-font-cdn/master/dubai-font.css);*/

#testimonios{
	background: rgba(30,30,30);
	width: 100%;
	min-height: 95vh;
	margin: 0;
	padding: 0;
	overflow-x: hidden;
	background-image: url('imgs/fondoTestis.jpg');
	background-size: cover;
	background-position: 50% 60%;
	background-repeat: no-repeat;
}
.testim {
	width: 100%;
	padding: 10% 0;
	background: transparent;
}

.testim .wrap {
    position: relative;
    /*width: 100%;*/
    max-width: 90%;
    display: block;
    padding: 40px 20px;
    margin: auto;
}

.testim .arrow {
    display: block;
    position: absolute;
    color: #eee;
    cursor: pointer;
    font-size: 2em;
    top: 50%;
    -webkit-transform: translateY(-50%);
		-ms-transform: translateY(-50%);
		-moz-transform: translateY(-50%);
		-o-transform: translateY(-50%);
		transform: translateY(-50%);
    -webkit-transition: all .3s ease-in-out;    
    -ms-transition: all .3s ease-in-out;    
    -moz-transition: all .3s ease-in-out;    
    -o-transition: all .3s ease-in-out;    
    transition: all .3s ease-in-out;
    padding: 5px;
    z-index: 22222222;
}

.testim .arrow:before {
		cursor: pointer;
}

.testim .arrow:hover {
    color: #bc8c3e;
}
    

.testim .arrow.left {
    left: 10px;
}

.testim .arrow.right {
    right: 10px;
}

.testim .dots {
    width: 100%;
    position: absolute;
    left: 0%;
    bottom: 5%;
    text-align: center;
    padding-left: 0px;
}

.testim .dots .dot {
    list-style-type: none;
    display: inline-block;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 1px solid #eee;
    margin: 0 10px;
    cursor: pointer;
    -webkit-transition: all .5s ease-in-out;    
    -ms-transition: all .5s ease-in-out;    
    -moz-transition: all .5s ease-in-out;    
    -o-transition: all .5s ease-in-out;    
    transition: all .5s ease-in-out;
		position: relative;
}

.testim .dots .dot.active,
.testim .dots .dot:hover {
    background: #fcbf5d;
    border-color: #bc8c3e;
}

.testim .dots .dot.active {
    -webkit-animation: testim-scale .5s ease-in-out forwards;   
    -moz-animation: testim-scale .5s ease-in-out forwards;   
    -ms-animation: testim-scale .5s ease-in-out forwards;   
    -o-animation: testim-scale .5s ease-in-out forwards;   
    animation: testim-scale .5s ease-in-out forwards;   
}
    
.testim .cont {
    position: relative;
		overflow: hidden;
}

.testim .cont > div {
    text-align: center;
    position: absolute;
    top: 0;
    left: 0;
    padding: 0 0 70px 0;
    opacity: 0;
}

.testim .cont > div.inactive {
    opacity: 1;
}
    

.testim .cont > div.active {
    position: relative;
    opacity: 1;
}
    

.testim .cont div .img img {
    display: block;
    width: 100px;
    height: 100px;
    margin: auto;
    border-radius: 50%;
}

.testim .cont div h5 {
    color: #bc8c3e;
    font-size: 1em;
    margin: 15px 0;
    font-family: 'Vincent';
}

.testim .cont div p {
    font-size: 1.15em;
    color: #eee;
    width: 80%;
    margin: auto;
}

.testim .cont div.active .img img {
    -webkit-animation: testim-show .5s ease-in-out forwards;            
    -moz-animation: testim-show .5s ease-in-out forwards;            
    -ms-animation: testim-show .5s ease-in-out forwards;            
    -o-animation: testim-show .5s ease-in-out forwards;            
    animation: testim-show .5s ease-in-out forwards;            
}

.testim .cont div.active h5 {
    -webkit-animation: testim-content-in .4s ease-in-out forwards;    
    -moz-animation: testim-content-in .4s ease-in-out forwards;    
    -ms-animation: testim-content-in .4s ease-in-out forwards;    
    -o-animation: testim-content-in .4s ease-in-out forwards;    
    animation: testim-content-in .4s ease-in-out forwards;    
}

.testim .cont div.active p {
    -webkit-animation: testim-content-in .5s ease-in-out forwards;    
    -moz-animation: testim-content-in .5s ease-in-out forwards;    
    -ms-animation: testim-content-in .5s ease-in-out forwards;    
    -o-animation: testim-content-in .5s ease-in-out forwards;    
    animation: testim-content-in .5s ease-in-out forwards;    
}

.testim .cont div.inactive .img img {
    -webkit-animation: testim-hide .5s ease-in-out forwards;            
    -moz-animation: testim-hide .5s ease-in-out forwards;            
    -ms-animation: testim-hide .5s ease-in-out forwards;            
    -o-animation: testim-hide .5s ease-in-out forwards;            
    animation: testim-hide .5s ease-in-out forwards;            
}

.testim .cont div.inactive h5 {
    -webkit-animation: testim-content-out .4s ease-in-out forwards;        
    -moz-animation: testim-content-out .4s ease-in-out forwards;        
    -ms-animation: testim-content-out .4s ease-in-out forwards;        
    -o-animation: testim-content-out .4s ease-in-out forwards;        
    animation: testim-content-out .4s ease-in-out forwards;        
}

.testim .cont div.inactive p {
    -webkit-animation: testim-content-out .5s ease-in-out forwards;    
    -moz-animation: testim-content-out .5s ease-in-out forwards;    
    -ms-animation: testim-content-out .5s ease-in-out forwards;    
    -o-animation: testim-content-out .5s ease-in-out forwards;    
    animation: testim-content-out .5s ease-in-out forwards;    
}

@-webkit-keyframes testim-scale {
    0% {
        -webkit-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -webkit-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -webkit-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -webkit-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-moz-keyframes testim-scale {
    0% {
        -moz-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -moz-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -moz-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -moz-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-ms-keyframes testim-scale {
    0% {
        -ms-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -ms-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -ms-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -ms-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-o-keyframes testim-scale {
    0% {
        -o-box-shadow: 0px 0px 0px 0px #eee;
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        -o-box-shadow: 0px 0px 10px 5px #eee;        
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        -o-box-shadow: 0px 0px 10px 5px #ea830e;        
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        -o-box-shadow: 0px 0px 0px 0px #ea830e;        
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@keyframes testim-scale {
    0% {
        box-shadow: 0px 0px 0px 0px #eee;
    }

    35% {
        box-shadow: 0px 0px 10px 5px #eee;        
    }

    70% {
        box-shadow: 0px 0px 10px 5px #ea830e;        
    }

    100% {
        box-shadow: 0px 0px 0px 0px #ea830e;        
    }
}

@-webkit-keyframes testim-content-in {
    from {
        opacity: 0;
        -webkit-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -webkit-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@-moz-keyframes testim-content-in {
    from {
        opacity: 0;
        -moz-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -moz-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@-ms-keyframes testim-content-in {
    from {
        opacity: 0;
        -ms-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -ms-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@-o-keyframes testim-content-in {
    from {
        opacity: 0;
        -o-transform: translateY(100%);
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        -o-transform: translateY(0);        
        transform: translateY(0);        
    }
}

@keyframes testim-content-in {
    from {
        opacity: 0;
        transform: translateY(100%);
    }
    
    to {
        opacity: 1;
        transform: translateY(0);        
    }
}

@-webkit-keyframes testim-content-out {
    from {
        opacity: 1;
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        -webkit-transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@-moz-keyframes testim-content-out {
    from {
        opacity: 1;
        -moz-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        -moz-transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@-ms-keyframes testim-content-out {
    from {
        opacity: 1;
        -ms-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        -ms-transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@-o-keyframes testim-content-out {
    from {
        opacity: 1;
        -o-transform: translateY(0);
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        transform: translateY(-100%);        
        transform: translateY(-100%);        
    }
}

@keyframes testim-content-out {
    from {
        opacity: 1;
        transform: translateY(0);
    }
    
    to {
        opacity: 0;
        transform: translateY(-100%);        
    }
}

@-webkit-keyframes testim-show {
    from {
        opacity: 0;
        -webkit-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -webkit-transform: scale(1);       
        transform: scale(1);       
    }
}

@-moz-keyframes testim-show {
    from {
        opacity: 0;
        -moz-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -moz-transform: scale(1);       
        transform: scale(1);       
    }
}

@-ms-keyframes testim-show {
    from {
        opacity: 0;
        -ms-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -ms-transform: scale(1);       
        transform: scale(1);       
    }
}

@-o-keyframes testim-show {
    from {
        opacity: 0;
        -o-transform: scale(0);
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        -o-transform: scale(1);       
        transform: scale(1);       
    }
}

@keyframes testim-show {
    from {
        opacity: 0;
        transform: scale(0);
    }
    
    to {
        opacity: 1;
        transform: scale(1);       
    }
}

@-webkit-keyframes testim-hide {
    from {
        opacity: 1;
        -webkit-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -webkit-transform: scale(0);
        transform: scale(0);
    }
}

@-moz-keyframes testim-hide {
    from {
        opacity: 1;
        -moz-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -moz-transform: scale(0);
        transform: scale(0);
    }
}

@-ms-keyframes testim-hide {
    from {
        opacity: 1;
        -ms-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -ms-transform: scale(0);
        transform: scale(0);
    }
}

@-o-keyframes testim-hide {
    from {
        opacity: 1;
        -o-transform: scale(1);       
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        -o-transform: scale(0);
        transform: scale(0);
    }
}

@keyframes testim-hide {
    from {
        opacity: 1;
        transform: scale(1);       
    }
    
    to {
        opacity: 0;
        transform: scale(0);
    }
}

@media all and (max-width: 300px) {
	body {
		font-size: 14px;
	}
}

@media all and (max-width: 500px) {
    #testimonios{
        padding-top: 30%;
    }
	.testim .arrow {
		font-size: 1.5em;
	}
	
	.testim .cont div p {
		line-height: 25px;
	}

}
</style>
<script src="https://use.fontawesome.com/1744f3f671.js"></script>
<script>
	// vars
'use strict'
var	testim = document.getElementById("testim"),
		testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 7500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
		touchStartPos,
		touchEndPos,
		touchPosDiff,
		ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
		
		testim.addEventListener("touchstart", function(e) {
				touchStartPos = e.changedTouches[0].clientX;
		})
	
		testim.addEventListener("touchend", function(e) {
				touchEndPos = e.changedTouches[0].clientX;
			
				touchPosDiff = touchStartPos - touchEndPos;
			
				console.log(touchPosDiff);
				console.log(touchStartPos);	
				console.log(touchEndPos);	

			
				if (touchPosDiff > 0 + ignoreTouch) {
						testimLeftArrow.click();
				} else if (touchPosDiff < 0 - ignoreTouch) {
						testimRightArrow.click();
				} else {
					return;
				}
			
		})
}
</script>


<section style="display:none">

	<div class="cont80x100">

	<div id="persoYcorpo">
	
		<div id="personalizado" style="cursor: pointer;" onclick="window.location='/personalizado'">

			<h2>personalizado</h2>

			<h6><a href="/personalizado">ver mas</a></h6>

		</div>

		<div id="corporativo" style="cursor: pointer;">

			<h2>corporativo</h2>

			<h6 id="pedidoCorpo">ver mas</h6>

		</div>

	</div>

	</div>

</section>




<footer>
	<div class="cont80x100">
	<div id="franjaTips">		
		<div>
			<img src="/imgs/shipped.png" width="50px" height="50px" alt="">
			<p>Envios gratis a todo el pais</p>
		</div>
		<div>
			<img src="/imgs/certificate.png" width="50px" height="50px" alt="">
			<p>12 meses de garantia</p>
		</div>
		<div>
			<img src="/imgs/money-back.png" width="50px" height="50px" alt="">
			<p>Hasta 7 dias para devolucion gratuita</p>
		</div>
		<div>
			<img src="/imgs/shield.png" width="50px" height="50px" alt="">
			<p>Compra 100% segura</p>
		</div>
	</div>
	</div>
</footer>

<style>
@media only screen and (min-width: 800px) {
	
footer{
	background-image: url('/imgs/franja4Tips.jpg');
	background-size: cover;
	background-position: center;
	background-repeat: no-repeat;
	padding: 5% 0;
	z-index: 99;
	position: relative;
}
#franjaTips{
	display: flex;
	justify-content: space-between;
}
#franjaTips>div{
	display: flex;
	align-items: center;
	width: 20%;
}
#franjaTips img{
	margin-right: 5%;
	display: block;
	margin: auto;
}
#franjaTips p{
	margin-left: 5%;
	font-family: 'Vincent';
	color: #cecece;
}

/*.todaviaNo{*/
/*	display: none!important;*/

/*}*/
/*article:hover{
	border: 1px rgba(0,0,0,0.5) dashed;
}*/
/*article:hover div{	*/
/*	transform: translate(10px, -10px) scale(1.02);*/
/*}*/
/*article:hover img{*/
/*	box-shadow: -10px 10px 15px 0px #ddd*/
/*}*/


/*#envioGratarola{*/
/*	width: 100%;*/
/*	top: 0;*/
/*	position: fixed;*/
/*	z-index: 999;*/
/*	background-image: linear-gradient( to top left, #bc8c3e, #fcbf5d );*/
/*	padding: 3px 0;*/
/*}*/
/*#envioGratarola>div{ position: relative; }*/
/*#envioGratarola p{*/
/*	text-align: center;*/
/*	font-size: 0.6em;*/
/*	font-weight: 400;*/
/*	color: white;*/
/*	width: 50%;*/
/*	display: block;*/
/*	margin: auto;*/
/*}*/
/*#envioGratarola span{*/
/*	position: absolute;*/
/*	font-weight: 400;*/
/*	color: white;*/
/*	right: 0;*/
/*	top: -50%;*/
/*	cursor: pointer;*/
/*}*/

}

@media only screen and (max-width: 799px) {
	

footer{
	background-image: url('/imgs/franja4Tips.jpg');
	background-size: cover;
	background-position: 60% 50%;
	background-repeat: no-repeat;
	padding: 10% 0;
	z-index: 99;
	position: relative;
}
#franjaTips{
/*	display: flex;
	justify-content: space-between;*/
}
#franjaTips>div{
	display: flex;
	justify-content: flex-start;
	align-items: center;
	width: 80%;
	margin: 10% auto;
}
#franjaTips img{
	margin-right: 10%;
	display: block;
}
#franjaTips p{
	margin-left: 5%;
	font-family: 'Vincent';
	color: #cecece;
}

.todaviaNo{
	display: none!important;

}
}
</style><!--<a target="_blank" href="https://wa.me/5491122558399">-->
<a target="_blank" href="https://wa.me/5491173698106">
    
<div id="wppBtn">
	<div>
		<svg height="100%" viewBox="-1 0 512 512" width="100%" xmlns="http://www.w3.org/2000/svg"><path d="m10.894531 512c-2.875 0-5.671875-1.136719-7.746093-3.234375-2.734376-2.765625-3.789063-6.78125-2.761719-10.535156l33.285156-121.546875c-20.722656-37.472656-31.648437-79.863282-31.632813-122.894532.058594-139.941406 113.941407-253.789062 253.871094-253.789062 67.871094.0273438 131.644532 26.464844 179.578125 74.433594 47.925781 47.972656 74.308594 111.742187 74.289063 179.558594-.0625 139.945312-113.945313 253.800781-253.867188 253.800781 0 0-.105468 0-.109375 0-40.871093-.015625-81.390625-9.976563-117.46875-28.84375l-124.675781 32.695312c-.914062.238281-1.84375.355469-2.761719.355469zm0 0" fill="#bc8c3e"/><path d="m10.894531 501.105469 34.46875-125.871094c-21.261719-36.839844-32.445312-78.628906-32.429687-121.441406.054687-133.933594 109.046875-242.898438 242.976562-242.898438 64.992188.027344 125.996094 25.324219 171.871094 71.238281 45.871094 45.914063 71.125 106.945313 71.101562 171.855469-.058593 133.929688-109.066406 242.910157-242.972656 242.910157-.007812 0 .003906 0 0 0h-.105468c-40.664063-.015626-80.617188-10.214844-116.105469-29.570313zm134.769531-77.75 7.378907 4.371093c31 18.398438 66.542969 28.128907 102.789062 28.148438h.078125c111.304688 0 201.898438-90.578125 201.945313-201.902344.019531-53.949218-20.964844-104.679687-59.09375-142.839844-38.132813-38.160156-88.832031-59.1875-142.777344-59.210937-111.394531 0-201.984375 90.566406-202.027344 201.886719-.015625 38.148437 10.65625 75.296875 30.875 107.445312l4.804688 7.640625-20.40625 74.5zm0 0" fill="#fff"/><path d="m19.34375 492.625 33.277344-121.519531c-20.53125-35.5625-31.324219-75.910157-31.3125-117.234375.050781-129.296875 105.273437-234.488282 234.558594-234.488282 62.75.027344 121.644531 24.449219 165.921874 68.773438 44.289063 44.324219 68.664063 103.242188 68.640626 165.898438-.054688 129.300781-105.28125 234.503906-234.550782 234.503906-.011718 0 .003906 0 0 0h-.105468c-39.253907-.015625-77.828126-9.867188-112.085938-28.539063zm0 0" fill="none"/><g fill="#fff"><path d="m10.894531 501.105469 34.46875-125.871094c-21.261719-36.839844-32.445312-78.628906-32.429687-121.441406.054687-133.933594 109.046875-242.898438 242.976562-242.898438 64.992188.027344 125.996094 25.324219 171.871094 71.238281 45.871094 45.914063 71.125 106.945313 71.101562 171.855469-.058593 133.929688-109.066406 242.910157-242.972656 242.910157-.007812 0 .003906 0 0 0h-.105468c-40.664063-.015626-80.617188-10.214844-116.105469-29.570313zm134.769531-77.75 7.378907 4.371093c31 18.398438 66.542969 28.128907 102.789062 28.148438h.078125c111.304688 0 201.898438-90.578125 201.945313-201.902344.019531-53.949218-20.964844-104.679687-59.09375-142.839844-38.132813-38.160156-88.832031-59.1875-142.777344-59.210937-111.394531 0-201.984375 90.566406-202.027344 201.886719-.015625 38.148437 10.65625 75.296875 30.875 107.445312l4.804688 7.640625-20.40625 74.5zm0 0"/><path d="m195.183594 152.246094c-4.546875-10.109375-9.335938-10.3125-13.664063-10.488282-3.539062-.152343-7.589843-.144531-11.632812-.144531-4.046875 0-10.625 1.523438-16.1875 7.597657-5.566407 6.074218-21.253907 20.761718-21.253907 50.632812 0 29.875 21.757813 58.738281 24.792969 62.792969 3.035157 4.050781 42 67.308593 103.707031 91.644531 51.285157 20.226562 61.71875 16.203125 72.851563 15.191406 11.132813-1.011718 35.917969-14.6875 40.976563-28.863281 5.0625-14.175781 5.0625-26.324219 3.542968-28.867187-1.519531-2.527344-5.566406-4.046876-11.636718-7.082032-6.070313-3.035156-35.917969-17.726562-41.484376-19.75-5.566406-2.027344-9.613281-3.035156-13.660156 3.042969-4.050781 6.070313-15.675781 19.742187-19.21875 23.789063-3.542968 4.058593-7.085937 4.566406-13.15625 1.527343-6.070312-3.042969-25.625-9.449219-48.820312-30.132812-18.046875-16.089844-30.234375-35.964844-33.777344-42.042969-3.539062-6.070312-.058594-9.070312 2.667969-12.386719 4.910156-5.972656 13.148437-16.710937 15.171875-20.757812 2.023437-4.054688 1.011718-7.597657-.503906-10.636719-1.519532-3.035156-13.320313-33.058594-18.714844-45.066406zm0 0" fill-rule="evenodd"/></g></svg>	</div>
</div>
</a>
<style>
#wppBtn{
		width: 8vh;
		height: 8vh;
		position: fixed;
		bottom: 3%;
		right: 2%;
		z-index: 9999;
		cursor: pointer;
		transition: .25s;
}
#wppBtn:hover{
	filter: saturate(1);
}


@media only screen and (max-width: 950px) {
#wppBtn{
	width: 12.5vw;
	height: 12.5vw;
}

</style>

<div id="modal"></div>

<div id="hechopor" style="    
	width: 100%;
    position: absolute;
    height: 14px;
    background-color: #fcbf5d;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    "><span style="    
    font-weight: bold;
    font-family: montserrat;
    font-size: 0.6em;
    margin-bottom: 2px;
    margin-top: 2px;">diseñada y programada con <3 por nosotros</span>
</div>

</body>



<script>

$( document ).ready(function() {


// Scroll cuando cliquean la primer flechita
window.requestAnimationFrame = (function() {
    return  window.requestAnimationFrame       ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame    ||
            window.oRequestAnimationFrame      ||
            window.msRequestAnimationFrame     ||
            function( callback ){
              window.setTimeout(callback, 130 / 30);
            };
  })();
  
  var scrollEngine = function() {
    var amount = 0;
    var scrollInProgess = false;
    var tailOff = 12;
  
    function evaluate (functionName) {
      amount = amount - Math.ceil(amount / tailOff);
      if (amount > 0) {
        requestAnimationFrame(functionName);
      } else {
        scrollInProgess = false;
      }
    }
  
    function scroll(timestamp) {
      window.scrollBy(0, Math.ceil(amount / tailOff));
      evaluate(scroll);
    }
  
    function scrollUp(timestamp) {
      window.scrollBy(0, -Math.ceil(amount / tailOff));
      evaluate(scrollUp);
    }
  
    return {
      setTailoff: function(tailAmount) {
        tailOff = tailAmount;
      },
      scrollToElementById: function(id, offset) {
        if (!scrollInProgess) {
          if (offset === undefined) {
            offset = 0;
          }
          scrollInProgess = true;
          var alreadyScrolled = (window.pageYOffset !== undefined) ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
          amount = document.getElementById(id).offsetTop - alreadyScrolled;
          amount = amount - offset;
          if (amount >= 0) {
            requestAnimationFrame(scroll);
          } else {
            amount = -amount;
            requestAnimationFrame(scrollUp);
          }
        }
      }
    };
  }();
  function handleClick(e) {
    e.preventDefault();
    var idSplit = this.getAttribute('href').split('#');
    if (idSplit.length > 1) {
      scrollEngine.scrollToElementById(idSplit[1], 0);
    }
  }
  
  var links = document.querySelectorAll('[href^=\'#\']');
  var limit = links.length;
  for (var n = 0; n < limit; n++) {
    links[n].addEventListener('click', handleClick);
  }
  //termin el scroll on click

    setTimeout(function() {



		if($(window).width() > 799){ 

			$('header h2').css({'letter-spacing':'2.5vw','opacity':'1'});

		}else{	$('header h2').css({'letter-spacing':'1.5vw','opacity':'1'}) }



		$('header h4').css({'transform':'translateY(0)','opacity':'1'})

   

		$('header li:nth-child(1),header li:nth-child(2)').css({'transform':'translateX(0)','opacity':'1'})



    setTimeout(function() {

		$('header li:nth-child(5),header li:nth-child(4)').css({'transform':'translateX(0)','opacity':'1'})



	}, 200);



    }, 150);









if($(window).width() > 799){ 

	$('header h2').css({'letter-spacing':'2.5vw','opacity':'1'});


}else{


$('header h2').css({'letter-spacing':'1.5vw','opacity':'1'}) }


$('aside h2').css({'letter-spacing':'2.5vw','opacity':'1'})

$(window).scroll(function() {

 	 var scroll = $(window).scrollTop();

 

var bottom_of_screen = $(window).scrollTop() + $(window).innerHeight();

var bottom_of_element1 = $("aside").offset().top + $("aside").outerHeight();



if (bottom_of_element1<bottom_of_screen) {

$('aside h4, aside p, #verSomos').css({'transform':'translateY(0)','opacity':'1'})

$('#verSomos').css('transform','translateY(0) translateX(-50%)')



};





var bottom_of_element2 = $("#persoYcorpo>div").offset().top + $("#persoYcorpo>div").outerHeight();

if (bottom_of_element2<bottom_of_screen+200) {

$("#persoYcorpo>div").css('transform', 'scale(1)')

}





 });





$('#verMasProc p, #verMasProc img').click(function() {

	

	$('#verMasProc').css('opacity','0');



	if ($('article').hasClass('todaviaNo')) {

		$('article').removeClass('todaviaNo');

	}



	$('html,body').animate({

    scrollTop: $("#procesoCont").offset().top},1600);



 	setTimeout(function() { 

       $('#verMasProc').css('display','none');

    }, 350);

})







$('#verSomos').click(function(){



	if ($('#verSomos p').text()=='VER MAS') {



	$('#verSomos img').css('transform','rotate(180deg)')

	$('#verSomos p').text('VER MENOS')



if($(window).width() > 799){ 

	$('#somosHidden').css({'position':'relative', 'display':'flex'})

}else{

	$('#somosHidden').css({'position':'relative', 'display':'block'})

}

	setTimeout(function() { 

       $('#somosHidden').css('opacity','1');

    }, 150);



	}

	else{

	$('#verSomos img').css('transform','rotate(0deg)')

	$('#verSomos p').text('VER MAS')



    $('#somosHidden').css('opacity','0');

	

	setTimeout(function() { 

	$('#somosHidden').css({'position':'relative', 'display':'none'})

    }, 150);

	}

})

//para eliminar todo lo del localstorage que no sea itemMarsten o itemBlackborrow
for (var g = 0; g < localStorage.length; g++){
var key3 = localStorage.key(g)
// var local_obj3 = JSON.parse( localStorage.getItem(key3) )

if( key3 == "itemBlackborrow" || key3 == "itemMarsten"){
    // $('#asi').append('<p>#0' + key3 + '</p>')
    console.log(key3)
}else{
    console.log(key3 + " OUT")
     localStorage.removeItem(key3)
}
}


if($(window).width() > 800){

// var lFollowX = 0,

//     lFollowY = 0,

//     x = 0,

//     y = 0,

//     friction = 1 / 30;

// function moveBackground() {

//   x += (lFollowX - x) * friction;

//   y += (lFollowY - y) * friction;

//   translate = 'translate(' + x + 'px, ' + y + 'px) scale(1.1)';

//   $('#shopNow img').css({

//     '-webit-transform': translate,

//     '-moz-transform': translate,

//     'transform': translate

//   });

//   window.requestAnimationFrame(moveBackground);

// }

// $(window).on('mousemove click', function(e) {

//   var lMouseX = Math.max(-100, Math.min(100, $(window).width() / 2 - e.clientX));

//   var lMouseY = Math.max(-100, Math.min(100, $(window).height() / 2 - e.clientY));

//   lFollowX = (20 * lMouseX) / 100; // 100 : 12 = lMouxeX : lFollow

//   lFollowY = (10 * lMouseY) / 100;

// });

// moveBackground();



}





$('#envioGratarola span').click(function(){

	$('#envioGratarola').slideUp('fast')

})


$('#pedidoCorpo').click(function(){
	$( "#modal" ).load( "modalCorpo.php" );
});

$('#corporativo').click(function(){
	$( "#modal" ).load( "modalCorpo.php" );
});



//CUUANDO CLICKEAS "SOMOS" EN EL NAV SE ABRE LA SECCION DEL VIDEOITO, PERRI
$('#somosAncla').click(function() {
    console.log("cachaplin")
	setTimeout(function() {
	$('#verSomos img').css('transform','rotate(180deg)')

	$('#verSomos p').text('VER MENOS')

console.log("cachaplin")

if($(window).width() > 799){ 

	$('#somosHidden').css({'position':'relative', 'display':'flex'})

}else{

	$('#somosHidden').css({'position':'relative', 'display':'block'})

}

	setTimeout(function() { 

       $('#somosHidden').css('opacity','1');

    }, 150);


   }, 200);
} )


// Codigo que los manda a la internacional si son de alguno de los paises de Europa o EEUU
// Array de esos paises
var countries = ['United States', 'Germany', 'Italy', 'Spain', 'France', 'Netherlands', 'United Kingdom', 'Norway', 'Denmark', 'Finland', 'Sweeden'];
 fetch('https://extreme-ip-lookup.com/json/')
.then( res => res.json())
.then(response => {
    console.log("Country: ", response.country);
    if(countries.includes(response.country)){
    	window.location = '/en';
    }
 })
 .catch((data, status) => {
    console.log('Request failed');
 })




});

</script>

</html>